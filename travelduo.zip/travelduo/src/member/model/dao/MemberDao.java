package member.model.dao;

import static common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import member.model.vo.Member;

public class MemberDao {

	public MemberDao() {}
	public Member selectLogin(Connection conn, String userId, String userPwd) {

		Member loginUser = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query =  "select * from member "
				+ "where userid = ? and userpwd = ?";
		
		try {
			pstmt=conn.prepareStatement(query);
			pstmt.setString(1, userId);
			pstmt.setString(2, userPwd);
			
			rset=pstmt.executeQuery();
		
			if(rset.next()) {
		
				loginUser = new Member();
				
				loginUser.setUserId(userId);
				loginUser.setUserPwd(userPwd);
				loginUser.setUserName(rset.getString("username"));
				loginUser.setPhone(rset.getString("phone"));
				loginUser.setEmail(rset.getString("email"));
				loginUser.setOn_off(rset.getString("on_off"));
				loginUser.setAge(rset.getInt("age"));
				loginUser.setGender(rset.getString("gender"));
				loginUser.setOimage(rset.getString("oimage"));
				loginUser.setRimage(rset.getString("rimage"));
				loginUser.setIntroduce(rset.getString("introduce"));
				loginUser.setTrust(rset.getInt("trust"));
	
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		
		return loginUser;
	}

	
	

	
}
