package product.model.vo;

public class Product implements java.io.Serializable {
	private static final long serialVersionUID = 100L;
	
	private String productNum;
	private String productName;
	private int productPrice;
	private String country;
	private String destination;
	private String destinationInfo;
	private String itinerary;

	public Product() {}
	
	public Product(String productNum, String productName, int productPrice, String country, String destination,
			String destinationInfo, String itinerary) {
		super();
		this.productNum = productNum;
		this.productName = productName;
		this.productPrice = productPrice;
		this.country = country;
		this.destination = destination;
		this.destinationInfo = destinationInfo;
		this.itinerary = itinerary;
	}

	public String getProductNum() {
		return productNum;
	}

	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDestinationInfo() {
		return destinationInfo;
	}

	public void setDestinationInfo(String destinationInfo) {
		this.destinationInfo = destinationInfo;
	}

	public String getItinerary() {
		return itinerary;
	}

	public void setItinerary(String itinerary) {
		this.itinerary = itinerary;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return this.productNum + ", " + this.productName + ", " + this.productPrice + ", " + this.country + ", " + this.destination + ", " + this.destinationInfo + ", " + this.itinerary;
	}
}
