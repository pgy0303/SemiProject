package admin.model.dao;

public class AdminDao {

}
