package board_hoogi.model.dao;

import static common.JDBCTemplate.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


import board_hoogi.model.vo.Product_Hoogi;

public class Product_Hoogi_DAO {
	
	public Product_Hoogi_DAO() {}

	//
	public ArrayList<Product_Hoogi> select_Hoogi(Connection conn, int currentPage, int limit) {
		
		ArrayList<Product_Hoogi> list = new ArrayList<Product_Hoogi>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		int startRow = (currentPage -1) * limit + 1;
		int endRow = startRow + limit - 1;
		
		//해당 페이지에 출력할 목록의 시작행과 끝행 계산
		//이라는데 나는 전체를 계산해놓음...
		//수정한, startrow 랑 endrow 가 ? ?부분에 들어감..
		
		String query = 
				"SELECT * FROM (SELECT ROWNUM RNUM, BOARD_NUM, userid, \r\n" + 
				"btitle, bcontent, board_date, product_num, \r\n" + 
				"boardOriginalFileName, boardRenameFileName from \r\n" + 
				"(SELECT * FROM product_hoogi ORDER BY board_num desC)\r\n" + 
				")\r\n" + 
				"WHERE RNUM >= ? AND RNUM <= ? ";
				
				
			/*	"SELECT * FROM (SELECT ROWNUM RNUM, BOARD_NUM, userid, \r\n" + 
						"btitle, bcontent, board_date, product_num, \r\n" + 
						"boardOriginalFileName, boardRenameFileName from product_hoogi)\r\n" + 
						"WHERE RNUM >= ? AND RNUM <= ? ORDER BY board_num desC";*/
		
	/*	"SELECT * FROM (SELECT ROWNUM RNUM, BOARD_NUM, userid, \r\n" + 
		"btitle, bcontent, board_date, product_num, \r\n" + 
		"boardOriginalFileName, boardRenameFileName from product_hoogi)\r\n" + 
		"WHERE RNUM >= ? AND RNUM <= ? ORDER BY board_num desC";*/
		
				/*"select rownum rnum, board_num, userid, btitle,"
				+ " bcontent, board_date, product_num, "
				+ "boardOriginalFileName, boardRenameFileName"
				+ "WHERE RNUM >= ? AND RNUM <= ?"
				+ " from Product_Hoogi ORDER BY board_num desC";*/
				
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			
			rset = pstmt.executeQuery();
			
			while(rset.next()) {	
				Product_Hoogi Phoogi = new Product_Hoogi();
				
				Phoogi.setBoardnum(rset.getInt("board_num"));
				Phoogi.setUserid(rset.getString("userid"));
				Phoogi.setBtitle(rset.getString("btitle"));
				Phoogi.setBcontent(rset.getString("bcontent"));
				Phoogi.setBoarddate(rset.getDate("board_date"));
				Phoogi.setProductnum(rset.getString("product_num"));
				Phoogi.setBoardOriginalFileName(rset.getString("boardOriginalFileName"));
				Phoogi.setBoardRenameFileName(rset.getString("boardRenameFileName"));
				
			//	BDto dto = new BDto(bId, bName, bTitle, bContent, bDate, bHit, bGroup, bStep, bIndent);
				
				list.add(Phoogi);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		
		return list;
	}


	public int inserthoogi(Connection conn, Product_Hoogi phoogi) {
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "insert into Product_Hoogi"
				+ "(board_num, userid, btitle, bcontent, board_date, product_num, boardOriginalFileName, boardRenameFileName)"
				+ "values(hoogi_seq.nextval, ?, ?, ?, sysdate, '제품번호임의', ?, ?)";
		
		try {
			pstmt = conn.prepareStatement(query);
			//pstmt.setInt(1, phoogi.getBoardnum());
			pstmt.setString(1, phoogi.getUserid());
			pstmt.setString(2, phoogi.getBtitle());
			pstmt.setString(3,  phoogi.getBcontent());
			pstmt.setString(4, phoogi.getBoardOriginalFileName());
			pstmt.setString(5, phoogi.getBoardRenameFileName());
			//pstmt.setDate(5, phoogi.getBoarddate());
			//pstmt.setString(6, phoogi.getProductnum());
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}		
	
		return result;
	}

	
	public int getListCount(Connection conn) {
		int listCount = 0;
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select count(*) from product_Hoogi";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			if(rset.next()) {
				listCount = rset.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		return listCount;
	}
	
	public ArrayList<Product_Hoogi> selectList (
			Connection conn, int currentPage, int limit) {
				
		
		// 중복일수있으니 검토해야함
		//-> 페이징 관련 메소드 시작행과 끝행 계산함
		return null;
		
	}
	
	//-> 게시글 번호로 한개 게시글 추출하는 메소드
	public Product_Hoogi selectHoogiNo(Connection conn, int HoogiNo) {
		
	Product_Hoogi Phoogi = null;
	PreparedStatement pstmt = null;
	ResultSet rset = null;
	
	String query = "select * from Product_Hoogi where board_num = ?";
	
	try {
		pstmt = conn.prepareStatement(query);
		pstmt.setInt(1, HoogiNo);
		
		rset = pstmt.executeQuery();
		
		if(rset.next()) {
			Phoogi = new Product_Hoogi();
			
			Phoogi.setBoardnum(rset.getInt("board_num"));
			Phoogi.setUserid(rset.getString("userid"));
			Phoogi.setBtitle(rset.getString("btitle"));
			Phoogi.setBcontent(rset.getString("bcontent"));
			Phoogi.setBoarddate(rset.getDate("board_date"));
			Phoogi.setProductnum(rset.getString("product_num"));
			Phoogi.setBoardOriginalFileName(rset.getString("boardOriginalFileName"));
			Phoogi.setBoardRenameFileName(rset.getString("boardRenameFileName"));
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		close(rset);
		close(pstmt);
	}
	
	return Phoogi;
		
	}


	public int insertReply(Connection conn, Product_Hoogi replyBoard) {
		return 0;
	//-->리플 입력하는 메소드
	}
	
	public int updateReply(Product_Hoogi Phoogi) {
		return 0;
	//--> 리플 수정하는 메소드
	}
	
	
	public int deleteReply(Product_Hoogi Phoogi) {
		return 0;
	//--> 리플 삭제하는 메소드
	}

	public ArrayList<Product_Hoogi> hoogiSearchTitle(String title, int 

	currentPage, int limit) {
		return null;
	//---> 후기 제목으로 검색하는 메소드
	}
	
	
	public ArrayList<Product_Hoogi> hoogiSearchWriter(String writer, int 

	currentPage, int limit){
		return null;

	//---> 후기 글쓴이로 검색하는 메소드
	}

	public ArrayList<Product_Hoogi> hoogiSearchContent(String writer, 

	int currentPage, int limit) {
		return null;

	//---> 후기 게시글의 제목이나 내용으로 검색하는 메소드
	}

	

	
	
	
}//전체
