package payment.model.dao;

public class PaymentDao {

}
