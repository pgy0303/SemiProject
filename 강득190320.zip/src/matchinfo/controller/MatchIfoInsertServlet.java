package matchinfo.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import matchinfo.model.service.MatchInfoService;
import matchinfo.model.vo.MatchInfo;

/**
 * Servlet implementation class MatchIfoInsertServlet
 */
@WebServlet("/miinsert")
public class MatchIfoInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MatchIfoInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//여행정보 입력 처리용 컨트롤러
				//1. 전송온 값에 한글이 있다면 인코딩 처리함
				request.setCharacterEncoding("utf-8");
				
				//2. 전송온 값 꺼내서 변수 또는 도메인객체에 저장
				MatchInfo minfo = new MatchInfo();
				
				/*minfo.setMatchUserNum(Integer.parseInt(request.getParameter("matchUserNum")));*/
				minfo.setMatchArea(request.getParameter("matchArea"));
				minfo.setMatchCity(request.getParameter("matchCity"));
				minfo.setDepartureDate(java.sql.Date.valueOf(request.getParameter("departureDate")));
				minfo.setArrivalDate(java.sql.Date.valueOf(request.getParameter("arrivalDate")));
				minfo.setMatchPlan(request.getParameter("matchPlan"));
				minfo.setMatchPrivate(request.getParameter("matchPrivate"));
				
				
				// 확인
				System.out.println("minfo : " + minfo);
				
				
				// 3.서비스모델로 객체 전달하고 결과 받기
				int result = new MatchInfoService().insertMatchInfo(minfo);
							
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
