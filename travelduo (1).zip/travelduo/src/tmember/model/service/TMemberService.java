package tmember.model.service;

import static common.JDBCTemplate.close;
import static common.JDBCTemplate.getConnection;

import java.sql.Connection;


import tmember.model.dao.TMemberDao;
import tmember.model.vo.TMember;

public class TMemberService {
	private TMemberDao mdao = new TMemberDao();
	
	public TMemberService() {}

	public TMember selectLogin(String userId, String userPwd) {
		Connection conn = getConnection();
		TMember loginUser = 
				mdao.selectLogin(conn, userId, userPwd);
		close(conn);
		return loginUser;
	}

}
