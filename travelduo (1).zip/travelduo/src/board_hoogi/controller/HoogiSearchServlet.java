package board_hoogi.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board_hoogi.model.vo.Product_Hoogi;
import board_hoogi.model.service.Product_Hoogi_Service;


/**
 * Servlet implementation class NoticeSearchServlet
 */
@WebServlet("/bsearch")
public class HoogiSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HoogiSearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 공지글 검색 처리용 컨트롤러
		//1. 
		request.setCharacterEncoding("utf-8");
		
		//2.
		String aa = (String) request.getAttribute("opt");
		
		String bb =  (String) request.getAttribute("condition");
		System.out.println("aa값은 :    " + aa + bb);
		System.out.println(bb + "입니다");

		
		//3.
		
		//HashMap<Integer, Product_Hoogi> map = null;
		//해쉬맵 어레이리스트로 변경
		ArrayList<Product_Hoogi> list = null;
		Product_Hoogi_Service hservice = new Product_Hoogi_Service();
		
		switch(aa) {
		case "title": String HoogiTitle = request.getParameter("keyword");
				  list = hservice.hoogiSearchTitle(HoogiTitle);
				  break;
		case "writer": String HoogiWriter = request.getParameter("keyword");
				  list = hservice.hoogiSearchWriter(HoogiWriter);
				  break;
		case "content": String HoogiContent = request.getParameter("keyword");
		  			list = hservice.hoogiSearchContent(HoogiContent);
		  				break;
		}
		
		//4.
		RequestDispatcher view = null;
		if(list.size() > 0) {
			view = request.getRequestDispatcher("views/notice/noticeListView.jsp");
			request.setAttribute("list", list);
			view.forward(request, response);
		}else {
			view = request.getRequestDispatcher("views/notice/noticeError.jsp");
			request.setAttribute("message", "요청된 조회결과가 없습니다.");
			view.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
