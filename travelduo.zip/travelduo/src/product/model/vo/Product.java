package product.model.vo;

public class Product implements java.io.Serializable {
	private static final long serialVersionUID = 100L;

	public Product() {}
	
	private String productNum;
	private int tQuantity;
	private int tPrice;
	private String productName;
	private String description;
	private String location;
	private String tImage;
	private String tTerm;
	private String timeTerm;

	public Product(String productNum, int tQuantity, int tPrice, String productName, String description,
			String location, String tImage, String tTerm, String timeTerm) {
		super();
		this.productNum = productNum;
		this.tQuantity = tQuantity;
		this.tPrice = tPrice;
		this.productName = productName;
		this.description = description;
		this.location = location;
		this.tImage = tImage;
		this.tTerm = tTerm;
		this.timeTerm = timeTerm;
	}

	public String getProductNum() {
		return productNum;
	}

	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}

	public int gettQuantity() {
		return tQuantity;
	}

	public void settQuantity(int tQuantity) {
		this.tQuantity = tQuantity;
	}

	public int gettPrice() {
		return tPrice;
	}

	public void settPrice(int tPrice) {
		this.tPrice = tPrice;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String gettImage() {
		return tImage;
	}

	public void settImage(String tImage) {
		this.tImage = tImage;
	}

	public String gettTerm() {
		return tTerm;
	}

	public void settTerm(String tTerm) {
		this.tTerm = tTerm;
	}

	public String getTimeTerm() {
		return timeTerm;
	}

	public void setTimeTerm(String timeTerm) {
		this.timeTerm = timeTerm;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
	return this.productNum + ", " + this.tQuantity + ", " + this.tPrice + ", " + this.productName + ", " + this.description + ", " + this.location
			 + ", " + this.tImage + ", " + this.tTerm + ", " + this.timeTerm;
}
	
}
