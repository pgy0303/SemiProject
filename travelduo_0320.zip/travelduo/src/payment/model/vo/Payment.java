package payment.model.vo;

public class Payment {

}
