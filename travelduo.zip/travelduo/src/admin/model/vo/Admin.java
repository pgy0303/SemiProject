package admin.model.vo;

public class Admin {

}
