package matchinfo.model.service;



import static common.JDBCTemplate.*;
import java.sql.Connection;
import matchinfo.model.dao.MatchInfoDao;
import matchinfo.model.vo.MatchInfo;


public class MatchInfoService {
	
	private MatchInfoDao mdao = new MatchInfoDao();
	
	public MatchInfoService (){}

	public int insertMatchInfo(MatchInfo minfo) {
		Connection conn = getConnection();
		int result = mdao.insertMatchInfo(conn, minfo);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
		
	}

	public MatchInfo selectLogin(String userId, String userPwd) {
		Connection conn = getConnection();
		MatchInfo loginUser = mdao.selectLogin(conn, userId, userPwd); //dao로 넘김
		close(conn);
		return loginUser;
	}

}
