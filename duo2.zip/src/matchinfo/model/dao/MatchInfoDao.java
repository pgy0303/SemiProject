package matchinfo.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static common.JDBCTemplate.*;

import matchinfo.model.vo.MatchInfo;

public class MatchInfoDao {

	public int insertMatchInfo(Connection conn, MatchInfo minfo) {
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "insert into matchinfo values (?, ?, ?, ?, ?, ?)";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, minfo.getMatchArea());
			pstmt.setString(2, minfo.getMatchCity());
			pstmt.setString(3, minfo.getMatchYear());
			pstmt.setString(4, minfo.getMatchMonth());
			pstmt.setString(5, minfo.getMatchPlan());
			pstmt.setString(6, minfo.getMatchPrivate());
	
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result;
	}

	public MatchInfo selectLogin(Connection conn, String matchPrivate) {
		MatchInfo loginUser = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null; //셀렉트문을 쓸거니까
		
		String query = "select * from matchinfo " + "where matchprivate = ?"; //멤버 테이블에서 조회해오기
		
		try {
			pstmt = conn.prepareStatement(query); //prepareStatement로 쿼리문 생성
			pstmt.setString(1, matchPrivate); //값 적용
		
			
			rset = pstmt.executeQuery(); //셀렉트 쿼리문이니 executeQuery사용
			
			if(rset.next()) { //rset이 제목행을 가르키니까 next로 한칸 내림.
				loginUser = new MatchInfo();
				
				
				loginUser.setMatchPrivate(rset.getString("matchprivate")); //rset이 참조하고 있는 위치의 sql 컬럼값 추출
							
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset); 
			close(pstmt);
		}
		
		return loginUser;
	}

}
