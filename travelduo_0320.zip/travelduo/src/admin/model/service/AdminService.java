package admin.model.service;

public class AdminService {

}
