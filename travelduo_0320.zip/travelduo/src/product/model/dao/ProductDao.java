package product.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import product.model.vo.Product;
import static common.JDBCTemplate.*;

public class ProductDao {

	public ArrayList<Product> selectList(Connection conn) {
		ArrayList<Product> list = new ArrayList<Product>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select * from product";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Product product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.setProductName(rset.getString("product_name"));
				product.setProductType(rset.getString("product_type"));
				product.setCountry(rset.getString("country"));
				product.setTravelDestination(rset.getString("travel_destination"));
				product.setTravelDestinationInfo(rset.getString("travel_destination_info"));
				product.setItinerary(rset.getString("itinerary"));
				product.setItineraryImage(rset.getString("itinerary_image"));
				product.setBannerImage(rset.getString("banner_image"));
				product.setProductPrice(rset.getInt("product_price"));
				product.setPassengerCount(rset.getInt("passenger_count"));
				product.setdDepartureDateTime(rset.getString("d_departuer_date_time"));
				product.setdArrivalDateTime(rset.getString("d_arrival_date_time"));
				product.seteDepartureDateTime(rset.getString("e_departure_date_time"));
				product.seteArrivalDateTime(rset.getString("e_arrival_date_time"));
				
				list.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}

}
