package matchinfo.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class MatchInfo implements Serializable {

	private static final long serialVersionUID = -7561264699998249771L;
	
	private int matchUserNum;
	private String matchArea;
	private String matchCity;
	private Date departureDate;
	private Date arrivalDate;
	private String matchPlan;
	private String matchPrivate;
	
	public MatchInfo() {}

	public MatchInfo(int matchUserNum, String matchArea, String matchCity, Date departureDate, Date arrivalDate,
			String matchPlan, String matchPrivate) {
		super();
		this.matchUserNum = matchUserNum;
		this.matchArea = matchArea;
		this.matchCity = matchCity;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.matchPlan = matchPlan;
		this.matchPrivate = matchPrivate;
	}

	public int getMatchUserNum() {
		return matchUserNum;
	}

	public void setMatchUserNum(int matchUserNum) {
		this.matchUserNum = matchUserNum;
	}

	public String getMatchArea() {
		return matchArea;
	}

	public void setMatchArea(String matchArea) {
		this.matchArea = matchArea;
	}

	public String getMatchCity() {
		return matchCity;
	}

	public void setMatchCity(String matchCity) {
		this.matchCity = matchCity;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getMatchPlan() {
		return matchPlan;
	}

	public void setMatchPlan(String matchPlan) {
		this.matchPlan = matchPlan;
	}

	public String getMatchPrivate() {
		return matchPrivate;
	}

	public void setMatchPrivate(String matchPrivate) {
		this.matchPrivate = matchPrivate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	

	
	

}
