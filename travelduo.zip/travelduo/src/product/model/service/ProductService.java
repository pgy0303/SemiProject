package product.model.service;

import static common.JDBCTemplate.close;
import static common.JDBCTemplate.commit;
import static common.JDBCTemplate.getConnection;
import static common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;

import product.model.dao.ProductDao;
import product.model.vo.Product;

public class ProductService {
private ProductDao pdao = new ProductDao();
	
	public ProductService() {}

	public ArrayList<Product> selectList() {
		Connection conn = getConnection();
		ArrayList<Product> list = pdao.selectList(conn);
		close(conn);
		return list;
	}
	
}
