package matchinfo.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import matchinfo.model.service.MatchInfoService;
import matchinfo.model.vo.MatchInfo;

/**
 * Servlet implementation class MatchIfoInsertServlet
 */
@WebServlet("/miinsert")
public class MatchIfoInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MatchIfoInsertServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 여행정보 입력 처리용 컨트롤러
		// 1. 전송온 값에 한글이 있다면 인코딩 처리함
		request.setCharacterEncoding("utf-8");

		// 2. 전송온 값 꺼내서 변수 또는 도메인객체에 저장
		MatchInfo minfo = new MatchInfo();

		minfo.setMatchArea(request.getParameter("matcharea"));
		minfo.setMatchCity(request.getParameter("matchcity"));
		minfo.setMatchYear(request.getParameter("matchyear"));
		minfo.setMatchMonth(request.getParameter("matchmonth"));
		minfo.setMatchPlan(request.getParameter("matchplan"));
		minfo.setMatchPrivate(request.getParameter("matchprivate"));

		// 확인
		System.out.println("minfo : " + minfo);

		// 3.서비스모델로 객체 전달하고 결과 받기
		int result = new MatchInfoService().insertMatchInfo(minfo);

		System.out.println("result :" + result);

		// 4. 받은결과로 성공 실패에 따라 뷰를 선택해서 내보냄

		response.setContentType("text/html; charset=utf-8"); // 한글 안깨지게
		PrintWriter out = response.getWriter(); // getWriter()

		if (result > 0) {

			out.println("<script type='text/javascript'>");
			out.println("alert('등록완료!');");
			out.println("history.back();");
			out.println("</script>");
			out.flush();
			return;
		} else {
			out.println("<script type='text/javascript'>");
			out.println("alert('등록실패!');");
			out.println("history.back();");
			out.println("</script>");
			out.flush();
			return;
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
