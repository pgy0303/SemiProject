package product.model.dao;

import static common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import product.model.vo.Product;

public class ProductDao {

	public ArrayList<Product> selectList(Connection conn) {
		ArrayList<Product> list = new ArrayList<Product>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select * from product";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Product product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.setProductName(rset.getString("product_name"));
				product.setProductPrice(rset.getInt("product_price"));
				product.setCountry(rset.getString("country"));
				product.setDestination(rset.getString("destination"));
				product.setDestinationInfo(rset.getString("destination_info"));
				product.setItinerary(rset.getString("itinerary"));
				
				list.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}

	/*public ArrayList<Product> selectCountryList(Connection conn, String country) {
		ArrayList<Product> list = new ArrayList<Product>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select * from product where country = '일본";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Product product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.setProductName(rset.getString("product_name"));
				product.setProductPrice(rset.getInt("product_price"));
				product.setCountry(rset.getString("country"));
				product.setDestination(rset.getString("destination"));
				product.setDestinationInfo(rset.getString("destination_info"));
				product.setItinerary(rset.getString("itinerary"));
				
				list.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}*/
	
	public ArrayList<Product> selectCountryList(Connection conn, String country) {
		ArrayList<Product> list = new ArrayList<Product>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from product where country = ?";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, country);
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				Product product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.setProductName(rset.getString("product_name"));
				product.setProductPrice(rset.getInt("product_price"));
				product.setCountry(rset.getString("country"));
				product.setDestination(rset.getString("destination"));
				product.setDestinationInfo(rset.getString("destination_info"));
				product.setItinerary(rset.getString("itinerary"));
				
				list.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(pstmt);
		}
		
		return list;
	}
}
