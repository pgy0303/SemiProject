package board_hoogi.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board_hoogi.model.service.Product_Hoogi_Service;
import board_hoogi.model.vo.Product_Hoogi;

/**
 * Servlet implementation class NoticeDetailServlet
 */
@WebServlet("/bdetail")
public class HoogiDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HoogiDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//전송된 글번호에 대한 상세보기 처리용 컨트롤러
		int HoogiNo = Integer.parseInt(request.getParameter("bnum"));
		int currentPage = Integer.parseInt(request.getParameter("page"));
		
		Product_Hoogi_Service Pservice = new Product_Hoogi_Service();
		
		Product_Hoogi Phoogi = Pservice.selectHoogiNo(HoogiNo);
		
		response.setContentType("text/html; charset=utf-8");
		RequestDispatcher view = null;
		if(Phoogi != null) {
			view = request.getRequestDispatcher("views/board/hoogiDetailView.jsp");
			request.setAttribute("Phoogi", Phoogi);
			request.setAttribute("currentPage", currentPage);
			view.forward(request, response);
		}else {
			view = request.getRequestDispatcher("views/board/hoogiError.jsp");
			request.setAttribute("message", HoogiNo + "클릭한 번호 게시물 조회실패!");
			view.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
