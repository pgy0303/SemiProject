package tmember.model.vo;

public class TMember implements java.io.Serializable {
	private static final long serialVersionUID = 44443L;
	
	private String userid;
	private String userpwd;
	private String username;
	private int phone;
	private String email;
	private String on_off;
	private int age;
	private String gender;
	private String introduce;
	private int trust;
	private String oimage;
	private String rimage;
	
	public TMember() {}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOn_off() {
		return on_off;
	}

	public void setOn_off(String on_off) {
		this.on_off = on_off;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}


	public int getTrust() {
		return trust;
	}

	public void setTrust(int trust) {
		this.trust = trust;
	}

	public String getOimage() {
		return oimage;
	}

	public void setOimage(String oimage) {
		this.oimage = oimage;
	}

	public String getRimage() {
		return rimage;
	}

	public void setRimage(String rimage) {
		this.rimage = rimage;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return this.userid + ", " + this.userpwd + ", "
			+ this.username + ", " + this.phone + ", "
			+ this.email + ", " + this.on_off + ", "
			+ this.age + ", " + this.age + ", "
			+ this.gender + ", " + this.introduce + ", "
			+ this.trust + ", " + this.oimage + ","
			+ this.rimage;
	}
	
	
	

}
