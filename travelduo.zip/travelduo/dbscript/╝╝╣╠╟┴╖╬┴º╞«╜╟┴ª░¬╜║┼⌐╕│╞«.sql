drop table member;
CREATE TABLE Member (
	userid varchar2(50) primary key,
	name varchar2(50),
	userpwd number,
	email varchar2(50),
	birthday number,
	phone number,
	address varchar2(70),
	gender char(2),
	trust varchar2(30),
	p_image varchar2(30),
	introduce varchar(1500),
	on_off char(2)
);
COMMENT ON COLUMN member.userid IS '���̵�';
COMMENT ON COLUMN member.name IS '�̸�';
COMMENT ON COLUMN member.userpwd IS '��й�ȣ';
COMMENT ON COLUMN member.email IS '�̸���';
COMMENT ON COLUMN member.birthday IS '�������';
COMMENT ON COLUMN member.phone IS '��ȭ��ȣ';
COMMENT ON COLUMN member.address IS '�ּ�';
COMMENT ON COLUMN member.gender IS '����';
COMMENT ON COLUMN member.trust IS '�ŷڵ�';
COMMENT ON COLUMN member.p_image IS '�����ʻ���';
COMMENT ON COLUMN member.introduce IS '�ڱ�Ұ�';
COMMENT ON COLUMN member.on_off IS '��Ī����';
commit;

drop table t_product;
CREATE TABLE T_Product (
	product_num varchar2(30) primary key,
	t_quantity number,
	t_price number,
	product_name varchar2(50) not NULL,
	description varchar2(300) not null,
	location VARCHAR2(50) not NULL,
	t_image varchar2(30),
	t_term VARCHAR2(50) not null,
	time_term varchar2(50) not null
);

COMMENT ON COLUMN t_product.product_num IS '�����ǰ���̵�';
COMMENT ON COLUMN t_product.t_quantity IS '�ο���';
COMMENT ON COLUMN t_product.t_price IS '��ǰ����';
COMMENT ON COLUMN t_product.product_name IS '��ǰ��';
COMMENT ON COLUMN t_product.description IS '��ǰ����';
COMMENT ON COLUMN t_product.location IS '������';
COMMENT ON COLUMN t_product.t_image IS '�̹������ϸ�';
COMMENT ON COLUMN t_product.t_term IS '��������';
COMMENT ON COLUMN t_product.titme_term IS '����Ⱓ';
commit;

drop table product_hoogi;
CREATE TABLE Product_hoogi (
    board_num number primary key,
	userid varchar2(50) NOT NULL,
	btitle varchar2(50) NOT NULL,
	bcontent varchar2(2500) NOT NULL,
	board_date date ,
	b_image varchar2(30),
	product_num varchar2(30) NOT NULL,
    
    CONSTRAINT fk_userid FOREIGN KEY(userid) REFERENCES member ON DELETE CASCADE,
    CONSTRAINT fk_product_num FOREIGN KEY(product_num) REFERENCES t_product ON DELETE CASCADE
);

COMMENT ON COLUMN product_hoogi.board_num IS '�Խñ۹�ȣ';
COMMENT ON COLUMN product_hoogi.userid IS '���̵�';
COMMENT ON COLUMN product_hoogi.btitle IS '�Խñ�����';
COMMENT ON COLUMN product_hoogi.bcontent IS '�Խñ۳���';
COMMENT ON COLUMN product_hoogi.board_date IS '��ϳ�¥';
COMMENT ON COLUMN product_hoogi.b_image IS '�̹������ϸ�';
COMMENT ON COLUMN product_hoogi.product_num IS '�����ǰ���̵�';
commit;

drop table qna;
CREATE TABLE QNA (
	qna_num number primary key,
	userid varchar2(50)	NOT NULL,
	qna_title varchar2(50)	NOT NULL,
	qna_date date,
	qna_content varchar2(2500)	NOT NULL,
    CONSTRAINT fk_qna FOREIGN KEY(userid) REFERENCES member(userid) ON DELETE CASCADE
);

COMMENT ON COLUMN qna.num IS '�Խñ۹�ȣ';
COMMENT ON COLUMN qna.userid IS '�ۼ��ھ��̵�';
COMMENT ON COLUMN qna.qna_title IS '����';
COMMENT ON COLUMN qna.qna_date IS '�ۼ���';
COMMENT ON COLUMN qna.qna_content IS '��������';
commit;

drop table order;
CREATE TABLE Order (
	order_num number primary key,
	userid varchar2(50)	NOT NULL,
	order_date date,
	order_price number,
	product_num varchar2(30) NOT NULL,
    CONSTRAINT fk_order FOREIGN KEY(userid) REFERENCES member(userid)  ON DELETE CASCADE,
    CONSTRAINT fk_order FOREIGN KEY(product_num) REFERENCES t_product(product_num) ON DELETE CASCADE
);

COMMENT ON COLUMN order.num IS '�ֹ���ȣ';
COMMENT ON COLUMN order.userid IS '���̵�';
COMMENT ON COLUMN order.order_date IS '�ֹ���¥';
COMMENT ON COLUMN order.order_price IS '�Ѱ���';
COMMENT ON COLUMN order.product_num IS '�����ǰ���̵�';

commit;

drop table payment_info;
CREATE TABLE Payment_info (
	travel_id varchar2(50)primary key,
	pay_method varchar2(30),
	t_quantity number,
	total_price number,
	userid varchar2(50),
	pay_check char(2) not NULL,
	order_num number not NULL,
    CONSTRAINT fk_payment_info FOREIGN KEY(order_num) REFERENCES order(order_num) ON DELETE CASCADE
);

COMMENT ON COLUMN payment_info.travel_id IS '������ȣ';
COMMENT ON COLUMN payment_info.pay_method IS '�������';
COMMENT ON COLUMN payment_info.t_quantity IS '�ο���';
COMMENT ON COLUMN payment_info.total_price IS '�Ѱ���';
COMMENT ON COLUMN payment_info.userid IS '�����ھ��̵�';
COMMENT ON COLUMN payment_info.pay_check IS '��������';
COMMENT ON COLUMN payment_info.order_num IS '�ֹ���ȣ';

commit;

drop table notice;
CREATE TABLE Notice (
	g_num number primary key,
	g_content varchar2(2500) not null,
	g_title varchar2(50) not null,
	g_date date,
    g_file varchar2(50),
	userid varchar2(50)not null,
    CONSTRAINT fk_notice FOREIGN KEY(userid) REFERENCES member(userid) ON DELETE CASCADE
);

COMMENT ON COLUMN notice.g_num IS '�۹�ȣ';
COMMENT ON COLUMN notice.g_content IS '�۳���';
COMMENT ON COLUMN notice.g_title IS '������';
COMMENT ON COLUMN notice.g_date IS '��ϳ�¥';
COMMENT ON COLUMN notice.g_file IS '÷������';
COMMENT ON COLUMN notice.userid IS '���̵�';
commit;

drop table profile;
CREATE TABLE profile (
	pro_num number primary key,
	public_check char(2) not NULL,
	userid varchar2(50) NOT NULL,
	twhere varchar2(50),
	twhen varchar2(50),
	intro varchar2(1000),
    CONSTRAINT fk_profile FOREIGN KEY(userid) REFERENCES member(userid) ON DELETE CASCADE
);

COMMENT ON COLUMN profile.pro_num IS '�����ʹ�ȣ';
COMMENT ON COLUMN profile.public_check IS '��������';
COMMENT ON COLUMN profile.userid IS '���̵�';
COMMENT ON COLUMN profile.twhere IS '������';
COMMENT ON COLUMN profile.twhen IS '��������';
COMMENT ON COLUMN profile.intro IS '�󼼼���';

commit;

drop table qna_answer;
CREATE TABLE QNA_ANSWER (
	rep_num number primary key,
	userid varchar2(50)	NOT NULL,
	rep_check char(2),
	rep_content varchar(2000) not NULL,
    CONSTRAINT fk_qna_answer FOREIGN KEY(userid) REFERENCES member(userid)  ON DELETE CASCADE
);

COMMENT ON COLUMN qna_answer.rep_num IS '��۹�ȣ';
COMMENT ON COLUMN qna_answer.userid IS '�ۼ��ھ��̵�';
COMMENT ON COLUMN qna_answer.rep_check IS '�亯����';
COMMENT ON COLUMN qna_answer.rep_content IS '��۳���';

commit;
drop table matching_hoogi;
CREATE TABLE Matching_hoogi (
	pro_num number NOT NULL,
	hoogi_num number not NULL,
	hoogi_title varchar2(50) not NULL,
	hoogi_content varchar2(3000) not NULL,
	hoogi_date date,
	hoogi_image varchar2(30),
    CONSTRAINT fk_matching_hoogi FOREIGN KEY(pro_num) REFERENCES profile(pro_num)  ON DELETE CASCADE
);

COMMENT ON COLUMN matching_hoogi.pro_num IS '�����ʹ�ȣ';
COMMENT ON COLUMN matching_hoogi.hoogi_num IS '�ı�۹�ȣ';
COMMENT ON COLUMN matching_hoogi.hoogi_title IS '�ı�����';
COMMENT ON COLUMN matching_hoogi.hoogi_content IS '�ı�۳���';
COMMENT ON COLUMN matching_hoogi.hoogi_date IS '�ı��ϳ�¥';
COMMENT ON COLUMN matching_hoogi.hoogi_image IS '�ı����';

commit;