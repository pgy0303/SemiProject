package matchinfo.model.service;



import static common.JDBCTemplate.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import matchinfo.model.dao.MatchInfoDao;
import matchinfo.model.vo.MatchInfo;


public class MatchInfoService {
	
	private MatchInfoDao mdao = new MatchInfoDao();
	
	public MatchInfoService (){}

	public int insertMatchInfo(MatchInfo minfo) {
		Connection conn = getConnection();
		int result = mdao.insertMatchInfo(conn, minfo);
		if(result > 0)
			commit(conn);
		else
			rollback(conn);
		close(conn);
		return result;
		
	}

}
