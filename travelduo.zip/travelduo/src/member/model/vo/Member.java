package member.model.vo;

import java.io.Serializable;

public class Member implements Serializable{

	private static final long serialVersionUID= 8888L;

	private String userId;
	private String userPwd;
	private String userName;
	private String phone;
	private String email;
	private String on_off;
	private int age;
	private String gender;
	private String oimage;
	private String rimage;
	private String introduce;
	private int trust;
	

	public Member() {}


	public Member(String userId, String userPwd, String userName, String phone, String email, String on_off, int age,
			String gender, String oimage, String rimage, String introduce, int trust) {
		super();
		this.userId = userId;
		this.userPwd = userPwd;
		this.userName = userName;
		this.phone = phone;
		this.email = email;
		this.on_off = on_off;
		this.age = age;
		this.gender = gender;
		this.oimage = oimage;
		this.rimage = rimage;
		this.introduce = introduce;
		this.trust = trust;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserPwd() {
		return userPwd;
	}


	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getOn_off() {
		return on_off;
	}


	public void setOn_off(String on_off) {
		this.on_off = on_off;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getOimage() {
		return oimage;
	}


	public void setOimage(String oimage) {
		this.oimage = oimage;
	}


	public String getRimage() {
		return rimage;
	}


	public void setRimage(String rimage) {
		this.rimage = rimage;
	}


	public String getIntroduce() {
		return introduce;
	}


	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}


	public int getTrust() {
		return trust;
	}


	public void setTrust(int trust) {
		this.trust = trust;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	@Override
	public String toString() {
		return this.userId+","+this.userPwd+","+this.userName+","+this.phone
				+","+this.email+","+this.on_off+","+this.age+","+this.gender
				+","+this.oimage+","+this.rimage+","+this.introduce+","
				+this.trust;
	}
	
}
