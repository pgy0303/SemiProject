package product.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import product.model.vo.Product;
import static common.JDBCTemplate.*;

public class ProductDao {

	public ArrayList<Product> selectList(Connection conn) {
		ArrayList<Product> list = new ArrayList<Product>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select * from t_product";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Product product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.settQuantity(rset.getInt("t_quantity"));
				product.settPrice(rset.getInt("t_price"));
				product.setProductName(rset.getString("product_name"));
				product.setDescription(rset.getString("description"));
				product.setLocation(rset.getString("location"));
				product.settImage(rset.getString("t_image"));
				product.settTerm(rset.getString("t_term"));
				product.setTimeTerm(rset.getString("time_term"));
				
				list.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}

}
