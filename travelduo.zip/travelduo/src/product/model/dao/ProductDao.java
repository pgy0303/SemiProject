package product.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import product.model.vo.Product;
import static common.JDBCTemplate.*;

public class ProductDao {

	public ArrayList<Product> selectList(Connection conn, int currentPage, int limit) {
		ArrayList<Product> list = null;
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select from t_product";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Product product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.settQuantity(rset.getInt("t_quantity"));
				product.settPrice(rset.getInt("t_price"));
				product.setProductName(rset.getString("product_name"));
				product.setDescription(rset.getString("description"));
				product.setLocation(rset.getString("location"));
				product.settImage(rset.getString("t_image"));
				product.settTerm(rset.getString("t_trem"));
				product.setTimeTerm(rset.getString("time_term"));
				
				list.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}

	public Product selectProduct(Connection conn, String productNum) {
		Product product = null;
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "select from t_product";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			if(rset.next()) {
				product = new Product();
				
				product.setProductNum(rset.getString("product_num"));
				product.settQuantity(rset.getInt("t_quantity"));
				product.settPrice(rset.getInt("t_price"));
				product.setProductName(rset.getString("product_name"));
				product.setDescription(rset.getString("description"));
				product.setLocation(rset.getString("location"));
				product.settImage(rset.getString("t_image"));
				product.settTerm(rset.getString("t_trem"));
				product.setTimeTerm(rset.getString("time_term"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rset);
			close(stmt);
		}
		
		return product;
	}


	public int insertProduct(Connection conn, Product product) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateProduct(Connection conn, Product product) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteProduct(Connection conn, String boardNum) {
		// TODO Auto-generated method stub
		return 0;
	}

}
