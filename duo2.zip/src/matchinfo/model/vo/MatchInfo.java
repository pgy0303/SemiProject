package matchinfo.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class MatchInfo implements Serializable {

	private static final long serialVersionUID = -7561264699998249771L;
	

	private String matchArea;
	private String matchCity;
	private String matchYear;
	private String matchMonth;
	private String matchPlan;
	private String matchPrivate;
	
	public MatchInfo() {}

	public MatchInfo(String matchArea, String matchCity, String matchYear, String matchMonth, String matchPlan,
			String matchPrivate) {
		super();
		this.matchArea = matchArea;
		this.matchCity = matchCity;
		this.matchYear = matchYear;
		this.matchMonth = matchMonth;
		this.matchPlan = matchPlan;
		this.matchPrivate = matchPrivate;
	}

	public String getMatchArea() {
		return matchArea;
	}

	public void setMatchArea(String matchArea) {
		this.matchArea = matchArea;
	}

	public String getMatchCity() {
		return matchCity;
	}

	public void setMatchCity(String matchCity) {
		this.matchCity = matchCity;
	}

	public String getMatchYear() {
		return matchYear;
	}

	public void setMatchYear(String matchYear) {
		this.matchYear = matchYear;
	}

	public String getMatchMonth() {
		return matchMonth;
	}

	public void setMatchMonth(String matchMonth) {
		this.matchMonth = matchMonth;
	}

	public String getMatchPlan() {
		return matchPlan;
	}

	public void setMatchPlan(String matchPlan) {
		this.matchPlan = matchPlan;
	}

	public String getMatchPrivate() {
		return matchPrivate;
	}

	public void setMatchPrivate(String matchPrivate) {
		this.matchPrivate = matchPrivate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "MatchInfo [matchArea=" + matchArea + ", matchCity=" + matchCity + ", matchYear=" + matchYear
				+ ", matchMonth=" + matchMonth + ", matchPlan=" + matchPlan + ", matchPrivate=" + matchPrivate + "]";
	}
	
 	
	
	


}
