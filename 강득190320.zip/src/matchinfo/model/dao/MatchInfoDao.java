package matchinfo.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


import static common.JDBCTemplate.*;

import matchinfo.model.vo.MatchInfo;

public class MatchInfoDao {

	public int insertMatchInfo(Connection conn, MatchInfo minfo) {
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "insert into match_info "
				+ "values (default, ?, ?, ?, ?, ?, ?)";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, minfo.getMatchArea());
			pstmt.setString(2, minfo.getMatchCity());
			pstmt.setDate(3, minfo.getDepartureDate());
			pstmt.setDate(4, minfo.getArrivalDate());		
			pstmt.setString(5, minfo.getMatchPlan());
			pstmt.setString(6, minfo.getMatchPrivate());
	
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result;
	}

}
