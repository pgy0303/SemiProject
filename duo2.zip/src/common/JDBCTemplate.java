package common;

import java.sql.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

//SingleTon Design Pattern
public class JDBCTemplate {
	/*public static Connection getConnection() {
		Connection conn = null; //리턴할 커넥션의 초기값 설정
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); //오라클 드라이버 ojdbc6등록작업
			conn = DriverManager.getConnection( //연결에 대한 결과 받음. 드라이버 매니저를 통해 겟 커넥션으로 db연결처리
					"jdbc:oracle:thin:@127.0.0.1:1521:xe", //오라클에 연결하기위한 url
					"student", "student");
			conn.setAutoCommit(false); //db가 자동 커밋 안되게 false설정
			
		} catch (Exception e) {
			e.printStackTrace(); //콘솔에 에러 출력되게함
		}
		
		return conn;
	}*/
	
	//톰캣(WAS==웹컨테이너)이 제공하는 DBCP(DataBase Connection Pool)를 이용해서 데이터베이스 연결 처리
	//web/META-INF/context.xml  파일에 설정됨
	public static Connection getConnection() {
		Connection conn = null;
		try {
			//context.xml에 설정된 <Resource> 엘리먼트의 설정값을 읽어와서 DBCP에서 Connection을 받음
			Context initContext = new InitialContext();
			DataSource ds = (DataSource)initContext.lookup("java:comp/env/jdbc/oraDB");
			conn = ds.getConnection();
			conn.setAutoCommit(false);
		} catch (Exception e) {
			e.getStackTrace();
		}
		
		
		return conn;
	}
	
	
	public static void commit(Connection conn) { //커넥션이 필요하다.
		try {
			if(conn != null && !conn.isClosed()) { //conn이 null이 아니면서 conn이 닫혀있지않을때 conn을 commit해라
				conn.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void rollback(Connection conn) { //커넥션이 필요하다.
		try {
			if(conn != null && !conn.isClosed()) { //conn이 null이 아니면서 conn이 닫혀있지않을때 conn을 rollback해라
				conn.rollback();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(Connection conn) {
		try {
			if(conn != null && !conn.isClosed()) { //conn이 null이 아니면서 conn이 닫혀있지않을때 conn을 close해라
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(Statement stmt) { 
		try {
			if(stmt != null & !stmt.isClosed()) { //stmt이 null이 아니면서 stmt이 닫혀있지않을때 stmt을 close해라
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(ResultSet rset) { 
		try {
			if(rset != null && !rset.isClosed()) { //rset이 null이 아니면서 rset이 닫혀있지않을때 rset을 close해라
				rset.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}









