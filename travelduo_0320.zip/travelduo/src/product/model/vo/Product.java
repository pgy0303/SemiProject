package product.model.vo;

public class Product implements java.io.Serializable {
	private static final long serialVersionUID = 100L;

	public Product() {}
	
	private String productNum;
	private String productName;
	private String productType;
	private String country;
	private String travelDestination;
	private String travelDestinationInfo;
	private String itinerary;
	private String itineraryImage;
	private String bannerImage;
	private int productPrice;
	private int passengerCount;
	private String dDepartureDateTime;
	private String dArrivalDateTime;
	private String eDepartureDateTime;
	private String eArrivalDateTime;
	
	public Product(String productNum, String productName, String productType, String country, String travelDestination,
			String travelDestinationInfo, String itinerary, String itineraryImage, String bannerImage, int productPrice,
			int passengerCount, String dDepartureDateTime, String dArrivalDateTime, String eDepartureDateTime,
			String eArrivalDateTime) {
		super();
		this.productNum = productNum;
		this.productName = productName;
		this.productType = productType;
		this.country = country;
		this.travelDestination = travelDestination;
		this.travelDestinationInfo = travelDestinationInfo;
		this.itinerary = itinerary;
		this.itineraryImage = itineraryImage;
		this.bannerImage = bannerImage;
		this.productPrice = productPrice;
		this.passengerCount = passengerCount;
		this.dDepartureDateTime = dDepartureDateTime;
		this.dArrivalDateTime = dArrivalDateTime;
		this.eDepartureDateTime = eDepartureDateTime;
		this.eArrivalDateTime = eArrivalDateTime;
	}

	public String getProductNum() {
		return productNum;
	}



	public void setProductNum(String productNum) {
		this.productNum = productNum;
	}



	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}



	public String getProductType() {
		return productType;
	}



	public void setProductType(String productType) {
		this.productType = productType;
	}



	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	public String getTravelDestination() {
		return travelDestination;
	}



	public void setTravelDestination(String travelDestination) {
		this.travelDestination = travelDestination;
	}



	public String getTravelDestinationInfo() {
		return travelDestinationInfo;
	}



	public void setTravelDestinationInfo(String travelDestinationInfo) {
		this.travelDestinationInfo = travelDestinationInfo;
	}



	public String getItinerary() {
		return itinerary;
	}



	public void setItinerary(String itinerary) {
		this.itinerary = itinerary;
	}



	public String getItineraryImage() {
		return itineraryImage;
	}



	public void setItineraryImage(String itineraryImage) {
		this.itineraryImage = itineraryImage;
	}



	public String getBannerImage() {
		return bannerImage;
	}



	public void setBannerImage(String bannerImage) {
		this.bannerImage = bannerImage;
	}



	public int getProductPrice() {
		return productPrice;
	}



	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}



	public int getPassengerCount() {
		return passengerCount;
	}



	public void setPassengerCount(int passengerCount) {
		this.passengerCount = passengerCount;
	}



	public String getdDepartureDateTime() {
		return dDepartureDateTime;
	}



	public void setdDepartureDateTime(String dDepartureDateTime) {
		this.dDepartureDateTime = dDepartureDateTime;
	}



	public String getdArrivalDateTime() {
		return dArrivalDateTime;
	}



	public void setdArrivalDateTime(String dArrivalDateTime) {
		this.dArrivalDateTime = dArrivalDateTime;
	}



	public String geteDepartureDateTime() {
		return eDepartureDateTime;
	}



	public void seteDepartureDateTime(String eDepartureDateTime) {
		this.eDepartureDateTime = eDepartureDateTime;
	}



	public String geteArrivalDateTime() {
		return eArrivalDateTime;
	}



	public void seteArrivalDateTime(String eArrivalDateTime) {
		this.eArrivalDateTime = eArrivalDateTime;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return this.productNum + ", " + this.productName + ", " + this.productType + ", " + this.country + ", " + this.travelDestination + ", " + this.travelDestinationInfo
				 + ", " + this.itinerary + ", " + this.itineraryImage + ", " + this.bannerImage + ", " + this.productPrice + ", " + this.passengerCount + ", " + this.dDepartureDateTime
				 + ", " + this.dArrivalDateTime + ", " + this.eDepartureDateTime + ", " + this.eArrivalDateTime;
	}
	
}
